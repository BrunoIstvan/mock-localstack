# import boto3

# ENDPOINT_URL = 'http://localhost:4574'
# LAMBDA_FUNCTION
# REGION = 'us-west-1'
# ACCESS_KEY = 'AKIAIOSFODNN7EXAMPLE'
# SECRET_KEY = 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY'


def lambda_handler(event, context):

    return {'message': 'Lambda called'}
